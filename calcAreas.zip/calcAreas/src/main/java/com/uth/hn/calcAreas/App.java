package com.uth.hn.calcAreas;

import java.util.Scanner;

public class App {
    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);

        while (true) {
            System.out.println("-- Aplicacion para calcular Areas de figuras geometricas --- \n");
            System.out.println("Selecciona una operacion a continuacion:");
            System.out.println("1. Calcular el area de un circulo");
            System.out.println("2. Calcular el area de un cuadrado");
            System.out.println("3. Calcular el area de un rectangulo");
            System.out.println("4. Calcular el area de un triangulo");
            System.out.println("0. Exit \n");

            int opcion = scanner.nextInt();

            if (opcion == 0) {
                break;
            }

            double A = 0.0;
            String figura = "";

            switch (opcion) {
                case 1:
                    figura = "circulo";
                    System.out.print("Ingresar el RADIO del circulo: ");
                    double radio = scanner.nextDouble();
                    A = Calc.ACirculo(radio);
                    break;

                case 2:
                    figura = "cuadrado";
                    System.out.print("Ingresar el LADO del cuadrado: ");
                    double lado = scanner.nextDouble();
                    A = Calc.ACuadrado(lado);
                    break;

                case 3:
                    figura = "rectangulo";
                    System.out.print("Ingresar la BASE del rectangulo: ");
                    double B = scanner.nextDouble();
                    System.out.print("Ingresa la altura del rectangulo: ");
                    double H = scanner.nextDouble();
                    A = Calc.ARectangulo(B, H);
                    break;

                case 4:
                    figura = "triangulo";
                    System.out.print("Ingresar la BASE del triangulo: ");
                    B = scanner.nextDouble();
                    System.out.print("Ingresar la ALTURA del triangulo: ");
                    H = scanner.nextDouble();
                    A = Calc.ATriangulo(B, H);
                    break;

                default:
                    System.out.println("Opcion INCORRECTA, elige una opcion valida del menu!!");
                    continue;
            }

            System.out.println("El area del " + figura + " es: " + A + "\n");
        }

        scanner.close();
    }
}
