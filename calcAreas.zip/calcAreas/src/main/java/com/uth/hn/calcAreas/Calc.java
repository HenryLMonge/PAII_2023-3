package com.uth.hn.calcAreas;

public class Calc {
	
	    public static double ACirculo(double radio) {
	        return Math.PI * radio * radio;
	    }

	    public static double ACuadrado(double lado) {
	        return lado * lado;
	    }

	    public static double ARectangulo(double B, double H) {
	        return B * H;
	    }

	    public static double ATriangulo(double B, double H) {
	        return (B * H)/2;
	    }
	}
