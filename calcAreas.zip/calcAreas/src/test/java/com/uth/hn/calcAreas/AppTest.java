package com.uth.hn.calcAreas;

import static org.junit.Assert.assertEquals;
import org.junit.Test;

public class AppTest {
    @Test
    public void testCalcACirculo() {
        double radio = 25.0;
        double resultadoEsperado = 91.34;
        double resultadoReal = Calc.ACirculo(radio);
        assertEquals(resultadoEsperado, resultadoReal, 0.01);
    }
    @Test
    public void testCalcACuadrado() {
        double lado = 10.0;
        double resultadoEsperado = 20.0;
        double resultadoReal = Calc.ACuadrado(lado);
        assertEquals(resultadoEsperado, resultadoReal, 0.01);
    }

    @Test
    public void testCalcARectangulo() {
        double B = 11.0;
        double H = 6.0;
        double resultadoEsperado = 66.0;
        double resultadoReal = Calc.ARectangulo(B, H);
        assertEquals(resultadoEsperado, resultadoReal, 0.01);
    }

    @Test
    public void testCalcATriangulo() {
        double B = 15.0;
        double H = 5.0;
        double resultadoEsperado = 37.5;
        double resultadoReal = Calc.ATriangulo(B, H);
        assertEquals(resultadoEsperado, resultadoReal, 0.01);
    }
}
